<template>
  <div class="about text-center">
    <h1>About Us</h1>
    <img src="@/assets/logo.png">
  </div>
</template>
