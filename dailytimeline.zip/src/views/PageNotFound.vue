<template>
    <div class="main-container text-center">
        <h1>OOPS! 404</h1>
        <h2>The page you're looking for <br> is not avaiable</h2>
    </div>
</template>
<script>
export default {
    name: 'PageNotFound'
}
</script>